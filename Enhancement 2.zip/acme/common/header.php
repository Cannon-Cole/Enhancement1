<section class="headerTop">
    <img class="logoImg" src="/acme/images/site/logo.gif" alt="The ACME Logo">
    <p>
        <img class="accountImg" src="/acme/images/site/account.gif" alt="An image of a red folder">
        <a href="#" title="My Account">My Account</a>
    </p>
</section>
<nav>
    <ul>
        <li class="active">
            <a href="#" title="Home">Home</a>
        </li>
        <li>
            <a href="#" title="Cannon">Cannon</a>
        </li>
        <li>
            <a href="#" title="Explosive">Explosive</a>
        </li>
        <li>
            <a href="#" title="Misc">Misc</a>
        </li>
        <li>
            <a href="#" title="Rocket">Rocket</a>
        </li>
        <li>
            <a href="#" title="Trap">Trap</a>
        </li>
    </ul>
</nav>