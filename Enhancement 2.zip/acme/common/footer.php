<p>&copy; ACME&#44; All rights reserved.</p>
<p>All images used are believed to be in &quot;Fair Use&quot;. Please notify the author if any are not and they will be removed.</p>